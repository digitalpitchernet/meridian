# Meridian --- Module Registry

**Document ID:** MER-REG-001\
**Version:** 0.1\
**Status:** Working baseline --- pending founder review\
**Product:** Meridian\
**Parent organisation:** Digital Pitcher Networks (DPN)\
**Created:** 10 November 2026\
**Registry owner:** Founder

> This registry is the central inventory of Meridian's product modules
> and cross-cutting capabilities. It records their intended
> responsibilities, scope standing, relationships, specification state
> and verified implementation state. It is not a substitute for module
> specifications, architecture documents or a repository audit.

------------------------------------------------------------------------

## 1. Purpose

The Module Registry provides one authoritative index of the functional
structure of Meridian.

It exists to:

-   Establish a shared inventory of product modules.
-   Define the intended responsibility and boundaries of each module.
-   Prevent overlapping or duplicate capabilities.
-   Make dependencies and cross-module relationships visible.
-   Track the documentation and specification state of each module.
-   Separate product scope decisions from implementation evidence.
-   Coordinate work across the founder, designers, developers and AI
    agents.

Every substantial module should have a stable identifier and a clear
documentation trail.

## 2. Governing architectural discipline

The registry is maintained under the user's ratified **Aurelian Laws
v0.1**. The following laws are particularly relevant:

1.  **Discovery Precedes Architecture** --- do not define a module's
    detailed architecture before understanding the problem, users,
    workflows and evidence.
2.  **Procedure Protects Creativity** --- use a consistent process for
    proposing, evaluating and approving modules without suppressing
    exploration.
3.  **Architecture Precedes Implementation** --- establish the relevant
    architecture and specification before substantial implementation.
4.  **Identity Evolves Through Superior Reasoning** --- revise module
    boundaries or product concepts when stronger reasoning justifies it;
    do not preserve a weak structure merely because it is familiar.
5.  **Challenge Has Greater Constitutional Value Than Agreement** ---
    surface contradictions, weak assumptions and scope conflicts rather
    than agreeing by default.
6.  **Evidence Precedes Principle** --- distinguish observed facts from
    assumptions and unverified claims.
7.  **Coherence Governs Optimization** --- do not optimize one module in
    a way that damages the overall product.
8.  **The Whole Governs the Parts** --- evaluate module decisions in the
    context of Meridian as a coherent operating environment.

The Aurelian lifecycle for developing stronger architectural knowledge
is:

**Observation → Validated Discovery → Architectural Pattern →
Architectural Principle → Identity Principle → Candidate Law → Ratified
Law**

Candidate laws are not treated as ratified laws unless they are
separately approved through the established process.

## 3. Registry conventions

### 3.1 Module identifiers

Each module receives a stable ID in this format:

`MER-MOD-NNN`

IDs are permanent references. If a module is renamed, reorganised or
split, do not silently reuse its ID for a different concept. Record the
change and its relationship to previous IDs.

Cross-cutting capabilities use:

`MER-CAP-NNN`

A capability supports multiple modules or the product as a whole but is
not necessarily a user-facing module.

### 3.2 Status dimensions

Do not collapse scope, specification and implementation into one status.

**Scope standing**

-   `BASELINE CANDIDATE` --- included in the current proposed product
    baseline; pending founder approval of the relevant foundation.
-   `APPROVED` --- explicitly approved for product scope.
-   `PROPOSED` --- under consideration, not yet included in the approved
    baseline.
-   `DEFERRED` --- intentionally excluded from the current scope or
    sequence.
-   `REJECTED` --- explicitly decided against.
-   `UNDER REVIEW` --- a material scope or boundary decision is
    unresolved.

**Specification status**

-   `NOT STARTED`
-   `DISCOVERY`
-   `DRAFT`
-   `IN REVIEW`
-   `APPROVED`
-   `SUPERSEDED`

**Implementation status**

-   `UNVERIFIED` --- the current implementation has not yet been
    inspected and tested against defined criteria.
-   `NOT IMPLEMENTED` --- inspected and confirmed absent.
-   `PARTIAL` --- some relevant behaviour exists, but the full
    requirement is not met.
-   `VERIFIED` --- inspected and confirmed against the applicable
    acceptance criteria.
-   `BLOCKED` --- progress depends on an unresolved decision or
    dependency.

Use `UNVERIFIED` until the repository audit establishes the facts. Do
not infer that a module is absent, complete or functional from its
presence in this registry, a mock-up, a prompt or an earlier discussion.

### 3.3 Module lifecycle

A module or major capability generally moves through:

`PROPOSED → RESEARCH → APPROVED → SPECIFIED → BUILD → TEST → RELEASED`

Possible alternative outcomes include:

-   `INTEGRATE` --- fulfil the need through an external capability
    rather than building it natively.
-   `DEFER` --- retain the idea but postpone it.
-   `REJECT` --- close the proposal because it does not justify
    inclusion.

A module may also be split, merged or retired through an explicit
decision. Its history and references must be preserved.

## 4. Core module registry

The following modules reflect the current Meridian product-planning
baseline. They are **baseline candidates**, not a declaration that every
module has received final approval or has been implemented.

  ----------------------------------------------------------------------------------------
  ID            Module       Primary          Scope       Specification   Implementation
                             responsibility   standing                    
  ------------- ------------ ---------------- ----------- --------------- ----------------
  MER-MOD-001   Command      Present a useful BASELINE    NOT STARTED     UNVERIFIED
                Centre /     overview of      CANDIDATE                   
                Home         current                                      
                             activity,                                    
                             priorities and                               
                             relevant                                     
                             operational                                  
                             signals.                                     

  MER-MOD-002   Projects     Organise         BASELINE    NOT STARTED     UNVERIFIED
                             initiatives and  CANDIDATE                   
                             bodies of work                               
                             around intended                              
                             outcomes and                                 
                             related context.                             

  MER-MOD-003   Tasks        Manage           BASELINE    NOT STARTED     UNVERIFIED
                             actionable work, CANDIDATE                   
                             status, due                                  
                             dates and                                    
                             relevant                                     
                             relationships.                               

  MER-MOD-004   Calendar &   Present          BASELINE    NOT STARTED     UNVERIFIED
                Milestones   time-based       CANDIDATE                   
                             commitments and                              
                             significant                                  
                             targets or                                   
                             points of                                    
                             progress.                                    

  MER-MOD-005   Finances     Record, import,  BASELINE    NOT STARTED     UNVERIFIED
                             organise and     CANDIDATE                   
                             review relevant                              
                             business                                     
                             financial                                    
                             information.                                 

  MER-MOD-006   Contacts     Maintain useful  BASELINE    NOT STARTED     UNVERIFIED
                             records of       CANDIDATE                   
                             people and                                   
                             external                                     
                             business                                     
                             relationships.                               

  MER-MOD-007   Decisions    Preserve         BASELINE    NOT STARTED     UNVERIFIED
                             significant      CANDIDATE                   
                             choices, their                               
                             context and                                  
                             rationale.                                   

  MER-MOD-008   Vault /      Organise, store, BASELINE    NOT STARTED     UNVERIFIED
                Documents    retrieve and     CANDIDATE                   
                             relate important                             
                             business                                     
                             documents and                                
                             files.                                       

  MER-MOD-009   Reports      Present          BASELINE    NOT STARTED     UNVERIFIED
                             traceable        CANDIDATE                   
                             summaries of                                 
                             operational and                              
                             business                                     
                             information.                                 

  MER-MOD-010   Settings     Manage relevant  BASELINE    NOT STARTED     UNVERIFIED
                             user, workspace  CANDIDATE                   
                             and product                                  
                             preferences.                                 
  ----------------------------------------------------------------------------------------

### 4.1 Module boundary notes

These are initial responsibility boundaries, not complete
specifications:

-   **Command Centre / Home** is an overview and navigation experience.
    It should consume relevant information from other modules rather
    than become the authoritative owner of their records.
-   **Projects** organise work around outcomes. They should not absorb
    task-management responsibilities.
-   **Tasks** represent actionable work. Their relationships to
    Projects, Calendar and Milestones require detailed definition.
-   **Calendar & Milestones** groups related time and progress concepts
    for the initial registry. The lexicon distinguishes a Calendar Event
    from a Milestone. Whether they remain one module or require separate
    module boundaries should be decided through discovery and
    architecture, not assumed.
-   **Finances** begins with the established import-first direction.
    Direct banking or accounting integrations are not implied.
-   **Contacts** stores business relationship records. A Contact is not
    automatically a Meridian User.
-   **Decisions** preserves choices and rationale. It should not become
    a general-purpose notes module without a separate need and decision.
-   **Vault / Documents** is the product area for document organisation.
    It is distinct from the underlying storage provider and
    infrastructure.
-   **Reports** presents information sourced from other modules. It
    should not create unsupported or unexplained metrics.
-   **Settings** manages configuration. The ownership and scope of
    user-level, workspace-level and integration-level settings must be
    specified.

## 5. Cross-cutting capability registry

These capabilities support the product as a whole. They are tracked
separately from user-facing modules so that platform responsibilities do
not become artificial navigation items.

  ------------------------------------------------------------------------------------------------------
  ID            Capability        Responsibility      Current planning  Specification   Implementation
                                                      direction                         
  ------------- ----------------- ------------------- ----------------- --------------- ----------------
  MER-CAP-001   Workspace &       Establish the       Single workspace  NOT STARTED     UNVERIFIED
                Identity          user's access and                                     
                                  the                                                   
                                  single-workspace                                      
                                  operating boundary.                                   

  MER-CAP-002   Personalisation & Collect necessary   Planned setup     NOT STARTED     UNVERIFIED
                Setup             founder,            experience; exact                 
                                  organisation and    scope to be                       
                                  regional            defined                           
                                  preferences to                                        
                                  configure Meridian.                                   

  MER-CAP-003   Data & Storage    Define data         Both local and    NOT STARTED     UNVERIFIED
                                  persistence and     Supabase-backed                   
                                  document storage    document storage                  
                                  responsibilities,   direction                         
                                  including local and                                   
                                  Supabase-backed                                       
                                  elements.                                             

  MER-CAP-004   External          Govern connections  Google Calendar,  NOT STARTED     UNVERIFIED
                Integrations      to external         Gmail and Google                  
                                  services and their  Drive explored;                   
                                  permissions, data   each connection                   
                                  flows and failure   requires separate                 
                                  behaviour.          evaluation                        

  MER-CAP-005   Authentication &  Protect access,     Required          NOT STARTED     UNVERIFIED
                Security          credentials,        cross-cutting                     
                                  sensitive           responsibility;                   
                                  information and     actual controls                   
                                  authorised          to be audited                     
                                  operations.                                           

  MER-CAP-006   Design System &   Maintain shared     Dark default;     NOT STARTED     UNVERIFIED
                Navigation        visual,             balanced density                  
                                  interaction, layout and motion;                       
                                  and navigation      adaptive                          
                                  conventions.        branding; hybrid                  
                                                      navigation                        

  MER-CAP-007   Import & Export   Define controlled   Financial entry   NOT STARTED     UNVERIFIED
                                  data intake and,    is import-first;                  
                                  where approved,     exact formats and                 
                                  data portability    export scope                      
                                  workflows.          require discovery                 

  MER-CAP-008   Notifications &   Govern user-facing  No broad          NOT STARTED     UNVERIFIED
                Reminders         reminders and       notification                      
                                  attention signals,  system assumed;                   
                                  if required by      discover                          
                                  approved workflows. module-specific                   
                                                      needs first                       
  ------------------------------------------------------------------------------------------------------

A capability may later be promoted to a module only when it has a
distinct user-facing responsibility and the architectural case supports
that separation.

## 6. Provisional relationship map

The following relationships are hypotheses to guide repository
inspection and discovery. They are **not approved data architecture or
dependency contracts**.

  -----------------------------------------------------------------------
  Module / capability                 Relationships to investigate
  ----------------------------------- -----------------------------------
  Command Centre / Home               Reads relevant summaries from
                                      Projects, Tasks, Calendar &
                                      Milestones, Finances and Reports.

  Projects                            May relate to Tasks, Milestones,
                                      Contacts, Decisions and Documents.

  Tasks                               May relate to Projects and Calendar
                                      Events; exact scheduling semantics
                                      require discovery.

  Calendar & Milestones               May present events and milestones
                                      related to Projects and Tasks,
                                      alongside any approved external
                                      calendar connection.

  Finances                            Supplies financial information to
                                      relevant Reports and Command Centre
                                      views.

  Contacts                            May be referenced by Projects and
                                      other relationship-oriented
                                      records.

  Decisions                           May relate to Projects, Documents
                                      and other records that provide
                                      context.

  Vault / Documents                   May store or reference documents
                                      associated with multiple modules.

  Reports                             Consumes relevant, authorised
                                      information from other modules.

  Settings                            Configures user and product
                                      behaviour without becoming the
                                      owner of business records.

  Workspace & Identity                Provides the access and workspace
                                      context within which module records
                                      are managed.

  Data & Storage                      Supports persistence and retrieval;
                                      exact ownership and boundaries
                                      require architecture review.

  External Integrations               Exchanges only the data and actions
                                      approved for each specific
                                      connection.
  -----------------------------------------------------------------------

Do not implement a relationship solely because it appears in this table.
Validate it through discovery, data modelling and an approved
specification.

## 7. Module specification requirements

Before a module enters substantial implementation, its specification
should address the following where relevant:

1.  **Purpose:** The user problem and outcome the module serves.
2.  **Users and context:** Who uses it and in what circumstances.
3.  **Scope:** Included behaviour and explicit non-goals.
4.  **Core concepts:** Canonical terms and records involved.
5.  **Workflows:** Main user journeys and edge cases.
6.  **Data:** Records, fields, relationships, ownership and
    source-of-truth rules.
7.  **Dependencies:** Other modules, capabilities and external services.
8.  **Permissions:** Who can view or change relevant information.
9.  **Interface:** Views, interactions, responsive behaviour and states.
10. **Integrations:** Data flows, scopes, failures and recovery, if
    applicable.
11. **Acceptance criteria:** Verifiable conditions for completion.
12. **Testing:** Functional, integration, security, accessibility and
    recovery checks as appropriate.
13. **Operational considerations:** Maintenance, costs, reliability and
    support.
14. **Documentation references:** Related architecture decisions and
    other specifications.

Not every module requires equal depth in every category. The
specification should be proportionate to the actual risk and complexity.

## 8. Module documentation structure

Use a consistent location for module specifications:

``` text
docs/
└── 02-modules/
    ├── MODULE-REGISTRY.md
    ├── command-centre/
    │   └── MODULE-SPEC.md
    ├── projects/
    │   └── MODULE-SPEC.md
    ├── tasks/
    │   └── MODULE-SPEC.md
    ├── calendar-milestones/
    │   └── MODULE-SPEC.md
    ├── finances/
    │   └── MODULE-SPEC.md
    ├── contacts/
    │   └── MODULE-SPEC.md
    ├── decisions/
    │   └── MODULE-SPEC.md
    ├── vault/
    │   └── MODULE-SPEC.md
    ├── reports/
    │   └── MODULE-SPEC.md
    └── settings/
        └── MODULE-SPEC.md
```

Create individual specification files when the relevant module enters
discovery or specification. Do not generate empty documents for every
module merely to fill the directory.

## 9. How the registry is maintained

Update this registry whenever:

-   A module is proposed, approved, deferred or rejected.
-   A module's responsibility or boundary changes.
-   A module is split, merged, renamed or retired.
-   A specification is created, approved or superseded.
-   A dependency is validated or invalidated.
-   Implementation status changes after inspection and testing.
-   A cross-cutting capability is introduced or materially changed.

Every material update should record:

-   The affected module or capability ID.
-   The previous and new status or definition.
-   The reason and supporting evidence.
-   The approving authority.
-   The date and document version.
-   Related specifications and decision records that require updates.

Use Git commits and pull requests or equivalent review history to
preserve actual file revisions. The change log inside this document
provides a readable summary; it does not replace repository history.

## 10. Immediate next steps

The next actions are:

1.  Review the registry and confirm whether the module inventory
    reflects the intended Meridian V1 baseline.
2.  Preserve all module implementation statuses as `UNVERIFIED` until
    the repository audit.
3.  Bring the actual Meridian repository into the working environment.
4.  Conduct the Stage 1 audit defined in `PRODUCT-ROADMAP.md`.
5.  Reconcile this registry with the observed application: identify
    existing modules, partial functionality, missing capabilities,
    duplicated responsibilities and architectural constraints.
6.  Prioritise module discovery and specifications based on evidence,
    dependencies and founder approval.

Do not start writing detailed module specifications for every module
before the audit. The audit may reveal that some capabilities already
exist, have different boundaries or need to be corrected before further
design.

## 11. Change log

  -----------------------------------------------------------------------
  Version                 Date                    Change
  ----------------------- ----------------------- -----------------------
  0.1                     10 November 2026        Initial module and
                                                  cross-cutting
                                                  capability inventory
                                                  created. Implementation
                                                  states deliberately
                                                  marked `UNVERIFIED`
                                                  pending repository
                                                  audit.

  -----------------------------------------------------------------------

------------------------------------------------------------------------

**Guiding principle:** The registry describes the intended structure of
Meridian; discovery and evidence determine whether that structure is
correct, and verified implementation determines what actually exists.
