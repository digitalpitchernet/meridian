# Graph Report - meridian  (2026-11-08)

## Corpus Check
- 149 files · ~176,404 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 632 nodes · 2647 edges · 27 communities (24 shown, 2 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 46 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Dialog Components & Finance UI
- DOM Utilities & Date Formatting
- Date & Month Utilities
- Recovery Drill Tests
- App Bootstrap & Theme/Color
- Data Fixtures & Repositories
- Vault Schema & Module
- HTTP Test Suite
- Module Entry Points & Rendering
- Server Finance Adapters
- Finance Schema & Tables
- Vault Connector (PHP)
- Fixture Adapter Implementation
- Recovery PSQL Utilities
- Recovery Migrations Tests
- Vault Fixtures & SHA256
- Finance Parity Tests
- Core Schema & Finance Fixtures
- Recovery Compare & Drill
- HTTP Provision Users Tests
- Recovery Evidence & Persistence
- Recovery PGCTL Tests
- Connector Tests
- Serve Tool
- Recovery Paths Tests
- Git Hooks

## God Nodes (most connected - your core abstractions)
1. `h()` - 140 edges
2. `friendlyError()` - 57 edges
3. `stateBlock()` - 52 edges
4. `mount()` - 51 edges
5. `button()` - 50 edges
6. `select()` - 46 edges
7. `input()` - 45 edges
8. `icon()` - 44 edges
9. `openDialog()` - 44 edges
10. `field()` - 42 edges

## Surprising Connections (you probably didn't know these)
- `make()` --calls--> `createFixtureAdapter()`  [EXTRACTED]
  tests/app/data.test.mjs → app/data/adapters/fixture.js
- `setup()` --calls--> `createFixtureAdapter()`  [EXTRACTED]
  tests/app/finance-parity.test.mjs → app/data/adapters/fixture.js
- `make()` --calls--> `createFixtureAdapter()`  [EXTRACTED]
  tests/app/finance.test.mjs → app/data/adapters/fixture.js
- `repo()` --calls--> `createFixtureAdapter()`  [EXTRACTED]
  tests/app/m2.test.mjs → app/data/adapters/fixture.js
- `make()` --calls--> `createFixtureAdapter()`  [EXTRACTED]
  tests/app/participants.test.mjs → app/data/adapters/fixture.js

## Import Cycles
- None detected.

## Communities (27 total, 2 thin omitted)

### Community 0 - "Dialog Components & Finance UI"
Cohesion: 0.10
Nodes (93): formatDate(), formatDateTime(), formatMoney(), score(), FIN_ENUMS, eventDialog(), contactDialog(), decisionDialog() (+85 more)

### Community 1 - "DOM Utilities & Date Formatting"
Cohesion: 0.09
Nodes (88): append(), clear(), h(), mount(), svg(), daysBetween(), formatShortDate(), formatTime() (+80 more)

### Community 2 - "Date & Month Utilities"
Cohesion: 0.09
Nodes (55): addDays(), addMonths(), formatCount(), monthGrid(), MONTHS, pad(), startOfWeek(), todayIn() (+47 more)

### Community 3 - "Recovery Drill Tests"
Cohesion: 0.06
Nodes (31): a, ALLOW_SENTINEL, b, bizA, check(), classified, defDiffs, deviation (+23 more)

### Community 4 - "App Bootstrap & Theme/Color"
Cohesion: 0.12
Nodes (25): applyAccent(), applyTheme(), boot(), ctx, isMac, accentSolid(), contrast(), hex() (+17 more)

### Community 5 - "Data Fixtures & Repositories"
Cohesion: 0.17
Nodes (16): at(), buildFixtures(), DEV_BUSINESS_ID, DEV_PROFILE_ID, fid(), ids, adapter, safeStorage (+8 more)

### Community 6 - "Vault Schema & Module"
Cohesion: 0.16
Nodes (23): businessId, id, LINK_TARGETS, text, ts, uuid, VAULT_ENUMS, VAULT_TABLES (+15 more)

### Community 7 - "HTTP Test Suite"
Cohesion: 0.10
Nodes (21): as(), AUTH_ONLY, bytes, call(), denied(), detail, emptyOrDenied(), env (+13 more)

### Community 8 - "Module Entry Points & Rendering"
Cohesion: 0.12
Nodes (23): calendarModule, commandModule, contactsModule, addOptionForm(), decisionsModule, optionCard(), renderDecision(), renderRegister() (+15 more)

### Community 9 - "Server Finance Adapters"
Cohesion: 0.27
Nodes (14): accountBalances(), capitalTargetSummary(), commitmentStatus(), reasonRequired(), RPCS, settlementStatus(), sum(), VIEWS (+6 more)

### Community 10 - "Finance Schema & Tables"
Cohesion: 0.13
Nodes (14): businessId, check(), date, fkFail(), FUNDING_RECEIPTS, guardAllocationInsert(), guardTransactionInsert(), id (+6 more)

### Community 11 - "Vault Connector (PHP)"
Cohesion: 0.31
Nodes (16): mv_authenticate(), mv_config(), mv_consume_nonce(), mv_delete(), mv_get(), mv_header(), mv_is_https(), mv_main() (+8 more)

### Community 12 - "Fixture Adapter Implementation"
Cohesion: 0.26
Nodes (15): clone(), createFixtureAdapter(), applyDefaults(), beforeWrite(), checkColumn(), coerce(), deleteRow(), pushActivity() (+7 more)

### Community 13 - "Recovery PSQL Utilities"
Cohesion: 0.19
Nodes (14): exe(), psql(), rows(), BASE, migrationArgs(), restoreArgs(), run(), data (+6 more)

### Community 14 - "Recovery Migrations Tests"
Cohesion: 0.22
Nodes (10): EXPECTED_COUNT, parseManifest(), sha(), cases, here, lines, manifest, real (+2 more)

### Community 15 - "Vault Fixtures & SHA256"
Cohesion: 0.24
Nodes (8): buildVaultFixtures(), full(), FINANCE_TABLES, K, sha256(), sha256Bytes(), make(), session

### Community 16 - "Finance Parity Tests"
Cohesion: 0.31
Nodes (9): tx(), alloc(), cash(), code(), financialFixtures(), runFinancial(), setup(), status() (+1 more)

### Community 17 - "Core Schema & Finance Fixtures"
Cohesion: 0.24
Nodes (9): buildFinanceFixtures(), full(), businessId, date, id, SQLSTATE, TABLES, text (+1 more)

### Community 18 - "Recovery Compare & Drill"
Cohesion: 0.24
Nodes (7): area(), classify(), diff(), STORAGE_REUPLOAD_FIELDS, re, bad(), noted()

### Community 19 - "HTTP Provision Users Tests"
Cohesion: 0.25
Nodes (7): admin, env, fail(), plan, REFUSED, repo, TEST_USERS

### Community 20 - "Recovery Evidence & Persistence"
Cohesion: 0.31
Nodes (7): attempt(), finish(), json(), persist(), apiOutcome(), dir, writeDurable()

### Community 21 - "Recovery PGCTL Tests"
Cohesion: 0.42
Nodes (7): classifyPgCtlStatus(), cleanupCluster(), describe(), err(), harness(), pgctlExe, TIMEOUT_MS

### Community 22 - "Connector Tests"
Cohesion: 0.47
Nodes (3): check(), code_is(), rrmdir()

### Community 23 - "Serve Tool"
Cohesion: 0.50
Nodes (3): port, root, types

## Knowledge Gaps
- **111 isolated node(s):** `isMac`, `MONTHS`, `WEEK_START`, `ids`, `safeStorage` (+106 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 147 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **2 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `q()` connect `Fixture Adapter Implementation` to `Recovery Drill Tests`, `Recovery PSQL Utilities`?**
  _High betweenness centrality (0.227) - this node is a cross-community bridge._
- **Why does `createFixtureAdapter()` connect `Fixture Adapter Implementation` to `Date & Month Utilities`, `Data Fixtures & Repositories`, `Server Finance Adapters`, `Vault Fixtures & SHA256`, `Finance Parity Tests`?**
  _High betweenness centrality (0.138) - this node is a cross-community bridge._
- **Why does `deleteRow()` connect `Fixture Adapter Implementation` to `Server Finance Adapters`?**
  _High betweenness centrality (0.118) - this node is a cross-community bridge._
- **What connects `isMac`, `MONTHS`, `WEEK_START` to the rest of the system?**
  _111 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Dialog Components & Finance UI` be split into smaller, more focused modules?**
  _Cohesion score 0.10347985347985347 - nodes in this community are weakly interconnected._
- **Should `DOM Utilities & Date Formatting` be split into smaller, more focused modules?**
  _Cohesion score 0.09089108910891089 - nodes in this community are weakly interconnected._
- **Should `Date & Month Utilities` be split into smaller, more focused modules?**
  _Cohesion score 0.08852459016393442 - nodes in this community are weakly interconnected._