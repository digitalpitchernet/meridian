<?php return array (
  'storage_root' => 'C:\\xampp\\htdocs\\meridian\\tests\\connector/.work/store',
  'nonce_db' => 'C:\\xampp\\htdocs\\meridian\\tests\\connector/.work/nonces.sqlite',
  'require_https' => true,
  'trust_forwarded_proto' => true,
  'max_bytes' => 1048576,
  'clock_skew_seconds' => 300,
  'keys' => 
  array (
    'k1' => 
    array (
      'secret_hex' => 'ffe288729241fde61023284c0bb480b9c12da65578cf0e1b6be3e62282b578e2',
      'business_id' => '11111111-1111-4111-8111-111111111111',
      'scopes' => 
      array (
        0 => 'read',
        1 => 'write',
        2 => 'delete',
      ),
      'active' => true,
    ),
    'k2' => 
    array (
      'secret_hex' => '8f13e7f2d03a10e9a263d265d9c242d3b5dc9a61e080a6c77df7e3c0a8fa6a3a',
      'business_id' => '11111111-1111-4111-8111-111111111111',
      'scopes' => 
      array (
        0 => 'read',
        1 => 'write',
        2 => 'delete',
      ),
      'active' => true,
    ),
    'ro' => 
    array (
      'secret_hex' => '899ad43a73ea62760228bfbb8952e826dbbb593967bcebfd4cf057c884be8abd',
      'business_id' => '11111111-1111-4111-8111-111111111111',
      'scopes' => 
      array (
        0 => 'read',
      ),
      'active' => true,
    ),
    'other' => 
    array (
      'secret_hex' => 'c60dd9c5580505683c68f2e796359181ebec744969a1a1f048c2591af9788f7f',
      'business_id' => '22222222-2222-4222-8222-222222222222',
      'scopes' => 
      array (
        0 => 'read',
        1 => 'write',
        2 => 'delete',
      ),
      'active' => true,
    ),
    'old' => 
    array (
      'secret_hex' => 'f4e49dedb90c56d9aea7ccfbd7cbfac4fbac7594c85dc8d4631deb6f40e2ebc9',
      'business_id' => '11111111-1111-4111-8111-111111111111',
      'scopes' => 
      array (
        0 => 'read',
        1 => 'write',
        2 => 'delete',
      ),
      'active' => false,
    ),
  ),
);